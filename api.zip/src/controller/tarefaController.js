import { Router } from "express";
import { listTasks, insertTask, finishedTasks, updateTask, deleteTask } from "../repository/taskRepository.js";

let endpts = Router();

endpts.post('/task/insert', async (req, resp) => {
    let task = req.body;
    let data = await insertTask(task);
    resp.send(data);
});

endpts.put('/task/update', async (req, resp) => {
    let id = req.query.id;
    let task = req.query.task;

    let data = await updateTask(task, id);
    resp.send('Task Updated!!');
});

endpts.get('/tasks/finished', async (req, resp) => {
    let data = await finishedTasks();
    resp.send(data);
});

endpts.get('/tasks', async (req, resp) => {
    let data = await listTasks();
    resp.send(data);
});

endpts.delete('/task', async (req, resp) => {
    let id = req.query.id;
    let data = await deleteTask(id);
    resp.send('Task Deleted Successfully!!');
});

export default endpts;