import './index.scss';

export default function head (){


    return (

        <header className='com-head'>
            <img className='logo' src='/assets/images/logo-mm.png'   />
            <img src='/assets/images/img-usuario2.png' />
        </header>
    )
}