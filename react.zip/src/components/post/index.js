import './index.scss';

export default function PostComponent(props) {
    return (
        <div className='com-pos'>

            <div className='main-per'>
                <div className='perfil'>
                    <img src={props.per} alt='Profile' />
                </div>

                <div>
                    <div className='nm'>
                        <h1>{props.usu}</h1>
                        <h2> • {props.temp} </h2>
                    </div>
                    <img src='/assets/images/verificado.png' alt='Verified' />
                </div>
            </div>

            <div className='img'>
                <img src={props.img} alt='Image' />
            </div>

            <div className='curt'>
                <div className='curtidas'>
                    <img src='/assets/images/im1.png' alt='Icon 1' />
                    <img src='/assets/images/im2.png' alt='Icon 2' />
                </div>

                <div className='curtidas'>
                    <h1>{props.curti} Curtidas</h1>
                </div>

                <div className='descricao'>
                    <h1>{props.usu}</h1>
                    <h2>{props.desc}</h2>
                </div>
            </div>
        </div>
    );
}