import './index.scss';

export default function monsbolso(props) {

    return (
        <div className='monster-pocket'>
            <div className='content'>
                <img className='profile-image' src={props.imag} alt="Monster Image" />
                <h1 className='name'> {props.nm}</h1>
                <h2 className='description'>{props.tp}</h2>
            </div>
        </div>
    )
}