import './index.scss';
import { useState } from 'react';
import axios from 'axios';
import monsbolso from '../../components/monstrobolso'; 

export default function Pokemon() {
    const [pokemons, setPokemons] = useState([]);
    const [vm, setVm] = useState(0);
    const [url, setUrl] = useState('https://pokeapi.co/api/v2/pokemon');
    const [nmPokemon, setNmPokemon] = useState('');}

    async function buscarPokemon() {
        let response = await axios.get(url);
        

        let listaPokemon = [];

        for (let item of response.data.results) {
            let pokemonResp = await axios.get(item.url);

            let imagem = pokemonResp.data.sprites.other['official-artwork'].front_default;

            let tipos = '';
            for (let t of pokemonResp.data.types) {
                tipos = tipos + t.type.name + '/'
                
            listaPokemon.push({
                nome: item.name,
                imagem: imagem,
                tipo: tipos
            })


        setPokemons(listaPokemon);
    }}

    async function mostrarShiny() {
        let shinyPokemons = await Promise.all(
            pokemons.map(async (pokemon) => {
                let response = await axios.get(`https://pokeapi.co/api/v2/pokemon/${pokemon.nome}`);
                let shinyImagem = response.data.sprites.other['official-artwork'].front_shiny;

                return {
                    ...pokemon,
                    imagem: shinyImagem,
                };
            })
        );

        setPokemons(shinyPokemons);
    }



    async function verMais() {
        setVm(vm + 20)
        setUrl('https://pokeapi.co/api/v2/pokemon?offset=0' + '&limit=' + vm)
        buscarPokemon()
    }
    async function buscar() {
        
        let response = await axios.get(`https://pokeapi.co/api/v2/pokemon/${nmPokemon}`);

        let novoPokemon = {
            nome: response.data.name,
            imagem: response.data.sprites.other['official-artwork'].front_default,
            tipo: response.data.types.map((t) => t.type.name).join('/'),
        };

        setPokemons([novoPokemon]);
  
}

    return (
        <div className='pagina-pokemon'>

            <section className='pokemon-section'>
                <img src='/assets/images/logoPokedex.png' alt='Logo Pokedex' />
                <div className='busca-container'>
                    <button className='buscar-button' onClick={buscarPokemon}>Encontrar pokemons</button>

                    <div className='input-container'>
                        <div>
                            <h2>Nome Pokemon</h2>
                            <input
                                type='text'
                                value={nmPokemon}
                                onChange={e => setNmPokemon(e.target.value)}
                            />
                        </div>
                        <button className='buscar-button' onClick={buscar}>
                            <img src='/assets/images/icon-buscar2.png' alt='Buscar' />
                        </button>
                    </div>
                </div>
                <div className='poke-container'>
                    {pokemons.map((pokemon) => (
                        <Pokemon
                            key={pokemon.nome}
                            nome={pokemon.nome}
                            imagem={pokemon.imagem}
                            tipo={pokemon.tipo}
                        />
                    ))}
                </div>

                <div className='botoes-container'>
                    <button className='vermais-button' onClick={verMais}>Ver mais</button>
                    <button className='shiny-button' onClick={mostrarShiny}>Shiny</button>
                </div>
            </section>
        </div>
    );
}