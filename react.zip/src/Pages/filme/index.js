import './index.scss';
import { useState } from 'react';
import axios from 'axios';

export default function Filme() {

    const [pagina, setPagina] = useState(1);
    const [filme, setFilme] = useState('');
    const [listafilme, setListafilme] = useState([]);
    const [filtro, setFiltro] = useState('');

    const escolherFiltro = (e) => {
        setFiltro(e.target.value);
    };

    function proxPagina() {
        if (pagina < 10) {
            let x = pagina++;
        }
        setPagina(pagina);
    }

    async function buscar() {
        let url = `http://www.omdbapi.com?apikey=4f301fbe&s=${filme}&type=${filtro}&page=${pagina}`;
        let busca = await axios.get(url);
        setListafilme(busca.data.Search);
    }

    function teclaEnter(e) {
        if (e.key === 'Enter') buscar();
    }

    function selecFiltro(e) {
        setFiltro(e);
    }

    return (
        <div className='pagina-carro'>
            <header className='header'>
                <img src='/assets/images/logo.svg' alt='Logo' />
                <h1 className='titulo'>Portifolio.me</h1>
            </header>
            <aside className='aside'>
                <section className='section'>
                    <div className='logo'>
                        <img src='/assets/images/img-film.png' alt='Logo Filme' />
                        <h3 className='titulo-logo'>IMDB</h3>
                    </div>

                    <div className='busca'>
                        <div className='input-container'>
                            <div>
                                <h2 className='titulo-input'>Novo item</h2>
                                <input
                                    className='inp1-input'
                                    type='text'
                                    value={filme}
                                    onKeyUp={teclaEnter}
                                    onChange={(e) => setFilme(e.target.value)}
                                />
                            </div>
                            <button className='inp1-button' onClick={buscar}>
                                <img src='/assets/images/icon-buscar.svg' alt='Buscar' />
                            </button>
                        </div>
                        <div className='tabela'>
                            <table>
                                <thead>
                                    <tr className='titulo-tabela'>
                                        <th className='tabela-codigo'>Código</th>
                                        <th className='tabela-titulo'>Título</th>
                                        <th className='tabela-ano'>Ano</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {listafilme.map((item) => (
                                        <tr key={item.imdbID} className='tabela-item'>
                                            <td className='tabela-cdg'>{item.imdbID}</td>
                                            <td className='tabela-nm'>{item.Title}</td>
                                            <td className='tabela-ano'>{item.Year}</td>
                                            <td className='tabela-img'>
                                                <img src={item.Poster} alt={item.Title} />
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <select className='select-filtro' value={filtro} onChange={escolherFiltro}>
                        <option value=''>Todos</option>
                        <option value='movie'>Filme</option>
                        <option value='series'>Série</option>
                        <option value='game'>Jogo</option>
                    </select>
                    <button className='button-proxPagina' onClick={proxPagina}>Próximo</button>
                </section>
            </aside>
        </div>
    );
}