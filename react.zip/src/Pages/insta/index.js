import './index.scss';
import { useState } from 'react';
import Post from '../../components/post';

export default function Insta() {
    const [usuario, setUsuario] = useState('');
    const [tempo, setTempo] = useState('');
    const [avatar, setAvatar] = useState('');
    const [descricao, setDescricao] = useState('');
    const [imagem, setImagem] = useState('');
    const [curtidas, setCurtidas] = useState(0);
    const [post, setPost] = useState([]);

    function adicionarPost() {
        let novoPos = {
            usuario: usuario,
            tempo: tempo,
            avatar: avatar,
            descricao: descricao,
            imagem: imagem,
            curtidas: curtidas,
        };

        setPost([...pos, novoPos]);

        setUsuario('');
        setTempo('');
        setAvatar('');
        setDescricao('');
        setImagem('');
        setCurtidas(0);
    }

    return (
        <section className='pagina-instagran'>
            <aside className='sidebar'>
                <div className='logo'>
                    <img src='/assets/images/logo2.png' alt='Logo' />
                    <h1>Portifolio.me</h1>
                </div>

                <div className='caminhos'>
                    <div>
                        <img src='/assets/images/img1.png' alt='Ícone 1' />
                        <h1>Página Inicial</h1>
                    </div>

                   
                </div>
            </aside>

            <nav className='nav'>
                <div className='novaspubli'>
                    <button> Novas Publicações </button>
                </div>

                <div className='users'>
                    <h1>
                        
                    </h1>
                </div>

                <article className='article'>
                    <div className='informacoes'>
                        <div className='inp1'>
                            <p>Usuário:</p>
                            <input value={usuario} onChange={e => setUsuario(e.target.value)} />
                            <p>Tempo:</p>
                            <input id='inp3' value={tempo} onChange={e => setTempo(e.target.value)} />
                        </div>

                        

                        <button onClick={adicionarPost}>Postar</button>
                    </div>
                </article>

                {post.map((post, index) => (
                    <Post
                        key={index}
                        avatar={post.avatar}
                        usuario={post.usuario}
                        tempo={post.tempo}
                        imagem={post.imagem}
                        curtidas={post.curtidas}
                        descricao={post.descricao}
                    />
                ))}
            </nav>
        </section>
    );
}