import './index.scss';
import { Link} from 'react-router-dom';

export default function Contato(){

    return(
        <div className='pag-contato'>
            <section className='container'>
                <h1> Contato</h1>
            </section>
        </div>
    )
}