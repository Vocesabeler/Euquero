import { useState } from 'react';
import './index.scss';
import { Link } from 'react-router-dom';
import axios from 'axios';

export default function Correio() {
    const [cep, setCEP] = useState('');
    const [info, setInfo] = useState('');

    async function buscar() {
        let url = 'https://viacep.com.br/ws/' + cep + '/json/';
        let resposta = await axios.get(url);

        setInfo(` ${resposta.data.logradouro}, ${resposta.data.bairro}`);
        setCEP('');
    }

    function teclaPressionada(e) {
        if (e.key === 'Enter') buscar();
    }

    return (
        <div className="pagina-correio">
            <div className="pagina-correio__container">
                <h1 className="pagina-correio__titulo">Correio</h1>
                <div>
                    CEP: <input
                        className="pagina-correio__input"
                        type="text"
                        value={cep}
                        onKeyUp={teclaPressionada}
                        onChange={(e) => setCEP(e.target.value)}
                    />
                    <button
                        className="pagina-correio__botao"
                        onClick={buscar}
                    >
                        Adicionar
                    </button>
                </div>
                <div>
                    <ul>
                        <li className="pagina-correio__info">{info}</li>
                    </ul>
                </div>
            </div>
            <Link className="pagina-correio__voltar" to="/">
                Voltar para Menu
            </Link>
        </div>
    );
}