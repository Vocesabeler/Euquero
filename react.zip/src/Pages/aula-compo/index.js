import './index.scss';
import Header from '../../components/header';
import Usuario from '../../components/usuario';
import { useState } from 'react';

export default function AulaCompo() {
    const [tema, setTema] = useState('');
    const [tema2, setTema2] = useState('');

    function dark() {
        setTema('dark');
    }

    function light() {
        setTema('light');
    }

    function op1() {
        setTema2('alternative-1');
    }

    function op2() {
        setTema2('alternative-2');
    }

    return (
        <body className='page-comp'>

            <Header />


            <aside className='content-wrapper'>
                <h1 className='page-title'> Aula - Componentes </h1>

                <div className={`content-row ${tema2}`}>
                    <Usuario tema={tema} nome="Bruno" curso="Técnico em Informática" num={1} conhecimentos={['Tudo de informatica']} />

                    <Usuario tema={tema} nome="" curso="" num={2} conhecimentos={['']} />
                </div>
                
                <div className={`content-row ${tema2}`}>
                    <Usuario tema={tema} nome="" curso="" num={3} conhecimentos={['']} />

                    <Usuario tema={tema} nome="" curso="" num={4} conhecimentos={['']} />
                </div>
            </aside>

            <nav className='nav-wrapper'>
                <button className='custom-button' onClick={dark}> Dark </button>
                <button className='custom-button' onClick={light}> Light</button>
            </nav>
            
            <nav className='nav-wrapper'>
                <button className='custom-button' onClick={op1}> Opção1 </button>
                <button className='custom-button' onClick={op2}> Opção2 </button>
            </nav>
        </body>
    );
}