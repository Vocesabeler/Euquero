import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.scss';

import App from './Pages/home';
import Tarefas from './Pages/lista-tarefas';
import Contato from './Pages/contato';
import Media from './Pages/media';
import AulaCompo from './Pages/aula-compo';
import Correio from './Pages/sedex';
import Aluno from './Pages/aluno';
import Sorvete from './Pages/sorve';
import Juros from './Pages/juros';
import Insta from './Pages/insta';
import Filme from './Pages/filme';
import Pokemon from './components/pokemon';

import {BrowserRouter,Routes,Route} from 'react-router-dom'
import AulaCompo from './Pages/aula-compo';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
  <BrowserRouter>
    <Routes>
      <Route path ='/home' element={<App />} />
      <Route path ='/filme' element={<Filme />} />
      <Route path='/pokemon' element={<Pokemon />} />
      <Route path ='/' element={<Insta />} />
      <Route path ='/sorve' element={<Sorvete />} />
      <Route path ='/media' element={<Media />} />
      <Route path ='/lista-tarefas' element={<Tarefas />} />
      <Route path ='/sedex' element={<Correio />} />
      <Route path ='/contato' element={<Contato />} />
      <Route path ='/aula-compo' element={<AulaCompo />} />
      <Route path ='/aluno' element={<Aluno />} />
      <Route path ='/juros' element={<Juros />} />
      
      
    </Routes>
  </BrowserRouter>
  </React.StrictMode>
);


